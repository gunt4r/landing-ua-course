import Header from "@/components/Header";
import Hero from "@/components/Hero";
import CountdownBanner from "@/components/CountdownBanner";
import About from "@/components/About";
import ForWhom from "@/components/ForWhom";
import Results from "@/components/Results";
import Program from "@/components/Program";
import Payment from "@/components/Payment";
import GuaranteeFAQ from "@/components/GuaranteeFAQ";
import FinalCTA from "@/components/FinalCTA";

export default function Home() {
  return (
    <>
      <div className="noise-overlay" aria-hidden="true" />
      <Header />
      <main>
        <Hero />
        <CountdownBanner />
        <About />
        <ForWhom />
        <Results />
        <Program />
        <Payment />
        <GuaranteeFAQ />
        <FinalCTA />
      </main>
    </>
  );
}
