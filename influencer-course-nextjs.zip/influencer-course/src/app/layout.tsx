import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Інфлюенсер Курс — Заробляй від $2500/місяць",
  description: "Дізнайся як створити Анінфлюенсера та заробляти від $2500 на місяць на донатах і рекламі",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="uk">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Montserrat:wght@300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
