export default function About() {
  const points = [
    {
      icon: "💸",
      title: "Реальний дохід",
      desc: "Вивчи перевірені методи монетизації через донати, рекламні інтеграції та партнерства.",
    },
    {
      icon: "⚡",
      title: "Швидкий старт",
      desc: "Від нуля до перших грошей за 30 днів. Структурована програма без зайвої теорії.",
    },
    {
      icon: "🎯",
      title: "Практика 100%",
      desc: "Кожен урок — це конкретне завдання з результатом. Тільки те, що реально працює.",
    },
    {
      icon: "🤝",
      title: "Підтримка",
      desc: "Особистий куратор, закрите ком'юніті та зворотній зв'язок на кожному кроці.",
    },
  ];

  return (
    <section
      id="about"
      style={{
        padding: "100px 24px",
        background: "#0A0A0A",
        position: "relative",
      }}
    >
      <div
        style={{
          maxWidth: "1100px",
          margin: "0 auto",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: "64px" }}>
          <div className="orange-badge" style={{ marginBottom: "16px" }}>
            У чому суть?
          </div>
          <h2 className="section-title" style={{ marginBottom: "16px" }}>
            Три види{" "}
            <span className="orange-text">доходу</span>
          </h2>
          <p
            style={{
              color: "rgba(255,255,255,0.55)",
              fontSize: "16px",
              maxWidth: "520px",
              margin: "0 auto",
              lineHeight: "1.7",
            }}
          >
            Ти зможеш одразу освоїти декілька джерел пасивного та активного
            доходу як анінфлюенсер
          </p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
            gap: "24px",
          }}
        >
          {points.map((point) => (
            <div key={point.title} className="card-dark gradient-border">
              <div
                style={{
                  width: "56px",
                  height: "56px",
                  background: "rgba(255,107,0,0.1)",
                  border: "1px solid rgba(255,107,0,0.25)",
                  borderRadius: "14px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "26px",
                  marginBottom: "20px",
                }}
              >
                {point.icon}
              </div>
              <h3
                style={{
                  fontFamily: "Montserrat, sans-serif",
                  fontWeight: "700",
                  fontSize: "18px",
                  color: "white",
                  marginBottom: "10px",
                }}
              >
                {point.title}
              </h3>
              <p
                style={{
                  color: "rgba(255,255,255,0.55)",
                  fontSize: "14px",
                  lineHeight: "1.65",
                }}
              >
                {point.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Income types section */}
        <div
          style={{
            marginTop: "80px",
            background: "linear-gradient(135deg, #111, #0f0a00)",
            border: "1px solid rgba(255,107,0,0.15)",
            borderRadius: "24px",
            padding: "48px",
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "48px",
            alignItems: "center",
          }}
        >
          <div>
            <div className="orange-badge" style={{ marginBottom: "20px" }}>
              Ексклюзив
            </div>
            <h3
              style={{
                fontFamily: "Montserrat, sans-serif",
                fontWeight: "800",
                fontSize: "clamp(24px, 3vw, 36px)",
                color: "white",
                lineHeight: "1.2",
                marginBottom: "24px",
              }}
            >
              Ти зможеш набути{" "}
              <span className="orange-text">три види доходу</span>
            </h3>

            {[
              { name: "Донати від глядачів", pct: 85 },
              { name: "Реклама та інтеграції", pct: 92 },
              { name: "Партнерські програми", pct: 74 },
            ].map((item) => (
              <div key={item.name} style={{ marginBottom: "20px" }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    marginBottom: "8px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "14px",
                      color: "rgba(255,255,255,0.8)",
                      fontWeight: "600",
                    }}
                  >
                    {item.name}
                  </span>
                  <span
                    style={{
                      fontSize: "14px",
                      color: "#FF6B00",
                      fontWeight: "700",
                    }}
                  >
                    {item.pct}%
                  </span>
                </div>
                <div className="progress-bar">
                  <div
                    className="progress-fill"
                    style={{ width: `${item.pct}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div>
            {[
              {
                icon: "🎮",
                title: "Ігровий стрімінг",
                desc: "Заробляй на донатах під час прямих трансляцій",
              },
              {
                icon: "📱",
                title: "Соціальні мережі",
                desc: "Монетизуй контент в TikTok, Instagram, YouTube",
              },
              {
                icon: "🤖",
                title: "AI-персонаж",
                desc: "Створи унікального анімованого персонажа-інфлюенсера",
              },
            ].map((item) => (
              <div
                key={item.title}
                style={{
                  display: "flex",
                  gap: "16px",
                  padding: "16px",
                  background: "rgba(255,255,255,0.03)",
                  borderRadius: "12px",
                  marginBottom: "12px",
                  border: "1px solid rgba(255,255,255,0.05)",
                }}
              >
                <div
                  style={{
                    fontSize: "28px",
                    width: "48px",
                    height: "48px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background: "rgba(255,107,0,0.1)",
                    borderRadius: "10px",
                    flexShrink: 0,
                  }}
                >
                  {item.icon}
                </div>
                <div>
                  <div
                    style={{
                      fontWeight: "700",
                      fontSize: "15px",
                      marginBottom: "4px",
                    }}
                  >
                    {item.title}
                  </div>
                  <div
                    style={{
                      fontSize: "13px",
                      color: "rgba(255,255,255,0.5)",
                    }}
                  >
                    {item.desc}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
