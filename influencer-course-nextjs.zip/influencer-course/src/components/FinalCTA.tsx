export default function FinalCTA() {
  return (
    <>
      {/* Final CTA */}
      <section
        style={{
          padding: "100px 24px",
          background: "linear-gradient(180deg, #0A0A0A 0%, #0f0700 50%, #1a0c00 100%)",
          position: "relative",
          overflow: "hidden",
          textAlign: "center",
        }}
      >
        {/* Radial glow */}
        <div
          style={{
            position: "absolute",
            bottom: "0",
            left: "50%",
            transform: "translateX(-50%)",
            width: "800px",
            height: "400px",
            background: "radial-gradient(ellipse at bottom, rgba(255,107,0,0.25) 0%, transparent 70%)",
            pointerEvents: "none",
          }}
        />

        <div style={{ maxWidth: "700px", margin: "0 auto", position: "relative" }}>
          <div className="orange-badge" style={{ marginBottom: "24px" }}>
            Останній крок
          </div>
          <h2
            style={{
              fontFamily: "Montserrat, sans-serif",
              fontWeight: "900",
              fontSize: "clamp(32px, 5vw, 60px)",
              color: "white",
              lineHeight: "1.1",
              marginBottom: "24px",
            }}
          >
            Готові піднятися на{" "}
            <span
              style={{
                color: "#FF6B00",
                position: "relative",
                display: "inline-block",
              }}
            >
              новий рівень?
              <svg
                style={{
                  position: "absolute",
                  bottom: "-8px",
                  left: 0,
                  width: "100%",
                }}
                viewBox="0 0 200 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M2 8C50 4 150 4 198 8"
                  stroke="#FF6B00"
                  strokeWidth="3"
                  strokeLinecap="round"
                  opacity="0.5"
                />
              </svg>
            </span>
          </h2>

          <p
            style={{
              color: "rgba(255,255,255,0.6)",
              fontSize: "17px",
              lineHeight: "1.7",
              marginBottom: "40px",
            }}
          >
            Приєднуйтесь до 500+ студентів, які вже будують свою фінансову
            незалежність через анінфлюенсинг. Місця обмежені.
          </p>

          <div
            style={{
              display: "flex",
              gap: "16px",
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <a
              href="#payment"
              className="btn-primary animate-pulse-glow"
              style={{ fontSize: "16px", padding: "18px 48px" }}
            >
              🚀 Почати навчання зараз
            </a>
          </div>

          <p
            style={{
              fontSize: "13px",
              color: "rgba(255,255,255,0.35)",
              marginTop: "20px",
            }}
          >
            🛡️ 14-денна гарантія повернення · 🔒 Безпечна оплата
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer
        style={{
          background: "#050505",
          padding: "40px 24px",
          borderTop: "1px solid rgba(255,107,0,0.1)",
        }}
      >
        <div
          style={{
            maxWidth: "1100px",
            margin: "0 auto",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "20px",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div
              style={{
                width: "32px",
                height: "32px",
                background: "linear-gradient(135deg, #FF6B00, #FF8C00)",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: "900",
                fontSize: "16px",
                color: "white",
              }}
            >
              А
            </div>
            <span
              style={{
                fontFamily: "Montserrat, sans-serif",
                fontWeight: "800",
                fontSize: "16px",
                color: "white",
              }}
            >
              ANI<span style={{ color: "#FF6B00" }}>FLUENCE</span>
            </span>
          </div>

          <div
            style={{
              display: "flex",
              gap: "24px",
              fontSize: "13px",
              color: "rgba(255,255,255,0.4)",
            }}
          >
            <a
              href="#"
              style={{
                color: "rgba(255,255,255,0.4)",
                textDecoration: "none",
                transition: "color 0.2s",
              }}
            >
              Умови використання
            </a>
            <a
              href="#"
              style={{
                color: "rgba(255,255,255,0.4)",
                textDecoration: "none",
                transition: "color 0.2s",
              }}
            >
              Політика конфіденційності
            </a>
            <a
              href="#"
              style={{
                color: "rgba(255,255,255,0.4)",
                textDecoration: "none",
                transition: "color 0.2s",
              }}
            >
              Повернення коштів
            </a>
          </div>

          <div
            style={{
              fontSize: "13px",
              color: "rgba(255,255,255,0.25)",
            }}
          >
            © 2025 AniFluence. Всі права захищені.
          </div>
        </div>
      </footer>
    </>
  );
}
