export default function Payment() {
  const bonuses = [
    { icon: "📱", title: "Чат-бот для збору донатів", val: "$197" },
    { icon: "📊", title: "Шаблони медіакітів", val: "$97" },
    { icon: "🎯", title: "База рекламодавців 200+", val: "$147" },
    { icon: "🤖", title: "AI-промпти для контенту", val: "$67" },
  ];

  return (
    <section
      id="payment"
      style={{
        padding: "100px 24px",
        background: "#0A0A0A",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* BG glow */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "900px",
          height: "900px",
          background: "radial-gradient(circle, rgba(255,107,0,0.06) 0%, transparent 60%)",
          pointerEvents: "none",
        }}
      />

      <div style={{ maxWidth: "900px", margin: "0 auto", position: "relative" }}>
        <div style={{ textAlign: "center", marginBottom: "48px" }}>
          <div className="orange-badge" style={{ marginBottom: "16px" }}>
            Здійсни оплату зараз та отримай усі бонуси
          </div>
          <h2 className="section-title">
            Обери свій{" "}
            <span className="orange-text">тарифний план</span>
          </h2>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "24px",
          }}
        >
          {/* Basic */}
          <div
            style={{
              background: "#111",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: "20px",
              padding: "36px",
            }}
          >
            <div
              style={{
                fontSize: "13px",
                fontWeight: "700",
                color: "rgba(255,255,255,0.5)",
                textTransform: "uppercase",
                letterSpacing: "1px",
                marginBottom: "16px",
              }}
            >
              Базовий
            </div>
            <div
              style={{
                fontFamily: "Bebas Neue, sans-serif",
                fontSize: "56px",
                color: "white",
                lineHeight: "1",
                marginBottom: "4px",
              }}
            >
              $197
            </div>
            <div
              style={{
                fontSize: "13px",
                color: "rgba(255,255,255,0.4)",
                marginBottom: "28px",
                textDecoration: "line-through",
              }}
            >
              $397
            </div>

            {[
              "Доступ до всіх 57 уроків",
              "Закрите ком'юніті",
              "Сертифікат про проходження",
              "2 місяці підтримки",
            ].map((feat) => (
              <div
                key={feat}
                style={{
                  display: "flex",
                  gap: "10px",
                  alignItems: "center",
                  marginBottom: "12px",
                }}
              >
                <div className="check-icon">
                  <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                    <path d="M1 4L4 7L9 1" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <span style={{ fontSize: "14px", color: "rgba(255,255,255,0.75)" }}>
                  {feat}
                </span>
              </div>
            ))}

            <a
              href="#"
              className="btn-secondary"
              style={{
                display: "block",
                textAlign: "center",
                marginTop: "28px",
              }}
            >
              Вибрати базовий
            </a>
          </div>

          {/* Premium */}
          <div
            style={{
              background: "linear-gradient(145deg, #1a0c00, #150a00)",
              border: "2px solid #FF6B00",
              borderRadius: "20px",
              padding: "36px",
              position: "relative",
              boxShadow: "0 0 60px rgba(255,107,0,0.2)",
            }}
          >
            {/* Popular badge */}
            <div
              style={{
                position: "absolute",
                top: "-14px",
                left: "50%",
                transform: "translateX(-50%)",
                background: "linear-gradient(135deg, #FF6B00, #FF8C00)",
                color: "white",
                fontSize: "12px",
                fontWeight: "700",
                padding: "6px 20px",
                borderRadius: "20px",
                letterSpacing: "0.5px",
                whiteSpace: "nowrap",
              }}
            >
              🔥 НАЙПОПУЛЯРНІШИЙ
            </div>

            <div
              style={{
                fontSize: "13px",
                fontWeight: "700",
                color: "#FF6B00",
                textTransform: "uppercase",
                letterSpacing: "1px",
                marginBottom: "16px",
              }}
            >
              Преміум
            </div>
            <div
              style={{
                fontFamily: "Bebas Neue, sans-serif",
                fontSize: "56px",
                color: "#FF6B00",
                lineHeight: "1",
                marginBottom: "4px",
              }}
            >
              $397
            </div>
            <div
              style={{
                fontSize: "13px",
                color: "rgba(255,255,255,0.4)",
                marginBottom: "28px",
                textDecoration: "line-through",
              }}
            >
              $797
            </div>

            {[
              "Все з базового тарифу",
              "Особистий куратор 3 місяці",
              "Зворотній зв'язок по контенту",
              "Доступ до закритих вебінарів",
              "Усі бонусні матеріали",
              "Безмежна підтримка у чаті",
            ].map((feat) => (
              <div
                key={feat}
                style={{
                  display: "flex",
                  gap: "10px",
                  alignItems: "center",
                  marginBottom: "12px",
                }}
              >
                <div className="check-icon">
                  <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                    <path d="M1 4L4 7L9 1" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <span style={{ fontSize: "14px", color: "rgba(255,255,255,0.85)", fontWeight: "500" }}>
                  {feat}
                </span>
              </div>
            ))}

            <a
              href="#"
              className="btn-primary animate-pulse-glow"
              style={{
                display: "block",
                textAlign: "center",
                marginTop: "28px",
                fontSize: "15px",
              }}
            >
              Отримати преміум доступ
            </a>
          </div>
        </div>

        {/* Bonuses */}
        <div style={{ marginTop: "56px" }}>
          <h3
            style={{
              fontFamily: "Montserrat, sans-serif",
              fontWeight: "800",
              fontSize: "22px",
              textAlign: "center",
              marginBottom: "28px",
              color: "white",
            }}
          >
            🎁 Бонуси при оплаті сьогодні (загалом{" "}
            <span className="orange-text">$508</span>)
          </h3>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(2, 1fr)",
              gap: "16px",
            }}
          >
            {bonuses.map((b) => (
              <div
                key={b.title}
                style={{
                  background: "#111",
                  border: "1px solid rgba(255,107,0,0.15)",
                  borderRadius: "14px",
                  padding: "20px",
                  display: "flex",
                  gap: "14px",
                  alignItems: "center",
                }}
              >
                <span style={{ fontSize: "28px" }}>{b.icon}</span>
                <div>
                  <div
                    style={{
                      fontSize: "14px",
                      fontWeight: "600",
                      color: "white",
                      marginBottom: "4px",
                    }}
                  >
                    {b.title}
                  </div>
                  <div
                    style={{
                      fontSize: "13px",
                      color: "#FF6B00",
                      fontWeight: "700",
                    }}
                  >
                    Вартість: {b.val}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Trend section */}
        <div
          style={{
            marginTop: "64px",
            background: "linear-gradient(135deg, #0f0a00, #1a0e00)",
            border: "1px solid rgba(255,107,0,0.2)",
            borderRadius: "20px",
            padding: "40px",
            textAlign: "center",
          }}
        >
          <div
            style={{
              fontFamily: "Bebas Neue, sans-serif",
              fontSize: "clamp(32px, 5vw, 56px)",
              color: "#FF6B00",
              marginBottom: "16px",
              letterSpacing: "2px",
            }}
          >
            ТРЕНД, поки ти проходиш
          </div>
          <p
            style={{
              color: "rgba(255,255,255,0.6)",
              fontSize: "15px",
              maxWidth: "600px",
              margin: "0 auto",
              lineHeight: "1.7",
            }}
          >
            Анінфлюенсери — це найгарячіший тренд 2024-2025. Ринок тільки
            формується, і зараз найкращий час зайняти своє місце. Через рік
            конкуренція буде в рази вища, а сьогодні це ще відкрита можливість.
          </p>
        </div>
      </div>
    </section>
  );
}
