export default function Program() {
  const modules = [
    {
      num: "01",
      title: "Вступ та налаштування",
      desc: "Основи анінфлюенсингу. Вибір нішіі, налаштування інструментів та технічна база.",
      lessons: 8,
      icon: "🚀",
    },
    {
      num: "02",
      title: "Створення персонажа",
      desc: "Розробка унікального AI-персонажа. Озвучка, анімація та брендинг.",
      lessons: 12,
      icon: "🎭",
    },
    {
      num: "03",
      title: "Контент-стратегія",
      desc: "Планування та виробництво контенту. Гайди для різних платформ.",
      lessons: 10,
      icon: "📋",
    },
    {
      num: "04",
      title: "Стрімінг та донати",
      desc: "Технічне налаштування стрімів. Психологія донатів та утримання аудиторії.",
      lessons: 9,
      icon: "🎮",
    },
    {
      num: "05",
      title: "Реклама та партнерства",
      desc: "Як знаходити рекламодавців, встановлювати ціни та укладати угоди.",
      lessons: 11,
      icon: "💼",
    },
    {
      num: "06",
      title: "Масштабування",
      desc: "Автоматизація процесів, команда та вихід на $5К+ на місяць.",
      lessons: 7,
      icon: "📈",
    },
  ];

  return (
    <section
      id="program"
      style={{
        padding: "100px 24px",
        background: "#080808",
      }}
    >
      <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "64px" }}>
          <div className="orange-badge" style={{ marginBottom: "16px" }}>
            Програма курсу
          </div>
          <h2 className="section-title">
            Що тебе{" "}
            <span className="orange-text">чекає</span> всередині
          </h2>
          <p
            style={{
              color: "rgba(255,255,255,0.5)",
              fontSize: "16px",
              marginTop: "16px",
            }}
          >
            57 уроків · 6 модулів · Довічний доступ
          </p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
            gap: "20px",
          }}
        >
          {modules.map((mod, idx) => (
            <div
              key={mod.num}
              style={{
                background: "#111",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: "18px",
                padding: "28px",
                position: "relative",
                overflow: "hidden",
                transition: "all 0.3s ease",
                cursor: "default",
              }}
              onMouseEnter={(e) => {
                const el = e.currentTarget as HTMLDivElement;
                el.style.borderColor = "rgba(255,107,0,0.4)";
                el.style.transform = "translateY(-4px)";
                el.style.boxShadow = "0 20px 40px rgba(0,0,0,0.4)";
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget as HTMLDivElement;
                el.style.borderColor = "rgba(255,255,255,0.07)";
                el.style.transform = "translateY(0)";
                el.style.boxShadow = "none";
              }}
            >
              {/* Background number */}
              <div
                style={{
                  position: "absolute",
                  right: "16px",
                  top: "16px",
                  fontFamily: "Bebas Neue, sans-serif",
                  fontSize: "80px",
                  color: "rgba(255,107,0,0.06)",
                  lineHeight: "1",
                  pointerEvents: "none",
                }}
              >
                {mod.num}
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "12px",
                  marginBottom: "16px",
                }}
              >
                <div
                  style={{
                    background: "rgba(255,107,0,0.12)",
                    border: "1px solid rgba(255,107,0,0.25)",
                    borderRadius: "10px",
                    padding: "10px",
                    fontSize: "22px",
                  }}
                >
                  {mod.icon}
                </div>
                <span
                  style={{
                    fontFamily: "Bebas Neue, sans-serif",
                    fontSize: "22px",
                    color: "#FF6B00",
                  }}
                >
                  Модуль {mod.num}
                </span>
              </div>

              <h3
                style={{
                  fontFamily: "Montserrat, sans-serif",
                  fontWeight: "700",
                  fontSize: "18px",
                  color: "white",
                  marginBottom: "10px",
                }}
              >
                {mod.title}
              </h3>
              <p
                style={{
                  fontSize: "14px",
                  color: "rgba(255,255,255,0.5)",
                  lineHeight: "1.6",
                  marginBottom: "16px",
                }}
              >
                {mod.desc}
              </p>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  fontSize: "12px",
                  color: "rgba(255,255,255,0.35)",
                  fontWeight: "600",
                }}
              >
                <span
                  style={{
                    width: "6px",
                    height: "6px",
                    background: "#FF6B00",
                    borderRadius: "50%",
                  }}
                />
                {mod.lessons} уроків
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
