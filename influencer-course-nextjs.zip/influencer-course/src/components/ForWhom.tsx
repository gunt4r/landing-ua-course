export default function ForWhom() {
  const categories = [
    {
      icon: "🎮",
      title: "Геймери",
      desc: "Хочеш монетизувати своє захоплення іграми та стримінгом",
    },
    {
      icon: "🎨",
      title: "Творці",
      desc: "Маєш творчі ідеї але не знаєш як на них заробити",
    },
    {
      icon: "📈",
      title: "Підприємці",
      desc: "Шукаєш нові джерела доходу в digital-просторі",
    },
    {
      icon: "🧑‍🎓",
      title: "Студенти",
      desc: "Хочеш незалежний дохід та гнучкий графік роботи",
    },
    {
      icon: "💼",
      title: "Фрілансери",
      desc: "Прагнеш масштабувати доходи та вийти на новий рівень",
    },
    {
      icon: "👨‍👩‍👧",
      title: "Батьки",
      desc: "Шукаєш можливість заробляти дистанційно з дому",
    },
  ];

  return (
    <section
      style={{
        padding: "100px 24px",
        background: "#080808",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* BG accent */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "800px",
          height: "800px",
          background:
            "radial-gradient(circle, rgba(255,107,0,0.04) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      <div style={{ maxWidth: "1100px", margin: "0 auto", position: "relative" }}>
        <div style={{ textAlign: "center", marginBottom: "64px" }}>
          <div className="orange-badge" style={{ marginBottom: "16px" }}>
            Для кого це?
          </div>
          <h2 className="section-title">
            Цей курс для <span className="orange-text">тебе</span>, якщо...
          </h2>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "20px",
          }}
        >
          {categories.map((cat) => (
            <div
              key={cat.title}
              style={{
                background: "linear-gradient(145deg, #151515, #111)",
                border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: "16px",
                padding: "28px",
                display: "flex",
                gap: "16px",
                alignItems: "flex-start",
                transition: "all 0.3s ease",
                cursor: "default",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLDivElement).style.borderColor =
                  "rgba(255,107,0,0.35)";
                (e.currentTarget as HTMLDivElement).style.transform =
                  "translateY(-4px)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLDivElement).style.borderColor =
                  "rgba(255,255,255,0.06)";
                (e.currentTarget as HTMLDivElement).style.transform =
                  "translateY(0)";
              }}
            >
              <div
                style={{
                  width: "52px",
                  height: "52px",
                  background: "rgba(255,107,0,0.1)",
                  border: "1px solid rgba(255,107,0,0.2)",
                  borderRadius: "12px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "24px",
                  flexShrink: 0,
                }}
              >
                {cat.icon}
              </div>
              <div>
                <h3
                  style={{
                    fontWeight: "700",
                    fontSize: "17px",
                    marginBottom: "6px",
                    color: "white",
                  }}
                >
                  {cat.title}
                </h3>
                <p
                  style={{
                    fontSize: "14px",
                    color: "rgba(255,255,255,0.5)",
                    lineHeight: "1.6",
                  }}
                >
                  {cat.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA block */}
        <div
          style={{
            marginTop: "64px",
            background: "linear-gradient(135deg, rgba(255,107,0,0.12), rgba(255,107,0,0.04))",
            border: "1px solid rgba(255,107,0,0.25)",
            borderRadius: "20px",
            padding: "48px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: "32px",
            flexWrap: "wrap",
          }}
        >
          <div>
            <h3
              style={{
                fontFamily: "Montserrat, sans-serif",
                fontWeight: "800",
                fontSize: "clamp(22px, 3vw, 34px)",
                color: "white",
                marginBottom: "12px",
              }}
            >
              Якщо ти впізнаєш себе хоч у{" "}
              <span className="orange-text">одному пункті</span> — це курс
              для тебе
            </h3>
            <p style={{ color: "rgba(255,255,255,0.55)", fontSize: "15px" }}>
              Не потрібен попередній досвід. Тільки бажання та 1-2 години на день.
            </p>
          </div>
          <a href="#payment" className="btn-primary" style={{ whiteSpace: "nowrap", fontSize: "15px" }}>
            Хочу на курс →
          </a>
        </div>
      </div>
    </section>
  );
}
