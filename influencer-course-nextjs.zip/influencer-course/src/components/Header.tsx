"use client";
import { useState, useEffect } from "react";

export default function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        transition: "all 0.3s ease",
        background: scrolled
          ? "rgba(10,10,10,0.95)"
          : "transparent",
        backdropFilter: scrolled ? "blur(20px)" : "none",
        borderBottom: scrolled ? "1px solid rgba(255,107,0,0.15)" : "none",
        padding: "16px 0",
      }}
    >
      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "0 24px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <div
            style={{
              width: "36px",
              height: "36px",
              background: "linear-gradient(135deg, #FF6B00, #FF8C00)",
              borderRadius: "8px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: "900",
              fontSize: "18px",
              color: "white",
            }}
          >
            А
          </div>
          <span
            style={{
              fontFamily: "Montserrat, sans-serif",
              fontWeight: "800",
              fontSize: "18px",
              color: "white",
            }}
          >
            ANI<span style={{ color: "#FF6B00" }}>FLUENCE</span>
          </span>
        </div>

        <nav
          style={{
            display: "flex",
            alignItems: "center",
            gap: "32px",
          }}
        >
          <a
            href="#about"
            style={{
              color: "rgba(255,255,255,0.7)",
              textDecoration: "none",
              fontSize: "13px",
              fontWeight: "600",
              letterSpacing: "0.5px",
              transition: "color 0.2s",
            }}
          >
            Про курс
          </a>
          <a
            href="#program"
            style={{
              color: "rgba(255,255,255,0.7)",
              textDecoration: "none",
              fontSize: "13px",
              fontWeight: "600",
              letterSpacing: "0.5px",
              transition: "color 0.2s",
            }}
          >
            Програма
          </a>
          <a
            href="#results"
            style={{
              color: "rgba(255,255,255,0.7)",
              textDecoration: "none",
              fontSize: "13px",
              fontWeight: "600",
              letterSpacing: "0.5px",
              transition: "color 0.2s",
            }}
          >
            Результати
          </a>
          <a href="#payment" className="btn-primary" style={{ padding: "10px 24px" }}>
            Записатись
          </a>
        </nav>
      </div>
    </header>
  );
}
