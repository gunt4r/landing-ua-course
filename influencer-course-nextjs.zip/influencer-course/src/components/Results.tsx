export default function Results() {
  const testimonials = [
    {
      name: "Олексій К.",
      role: "Геймер, 23 роки",
      income: "$2,840/міс",
      text: "За перший місяць після курсу зміг вийти на стабільний дохід. Спочатку не вірив, що це реально, але результат говорить сам за себе.",
      avatar: "ОК",
      stars: 5,
    },
    {
      name: "Марина В.",
      role: "Студентка, 20 років",
      income: "$1,650/міс",
      text: "Навчилась монетизувати TikTok та Instagram. Куратор завжди відповідав на питання. Рекомендую всім, хто хоче заробляти онлайн.",
      avatar: "МВ",
      stars: 5,
    },
    {
      name: "Дмитро Л.",
      role: "Фрілансер, 28 років",
      income: "$3,200/міс",
      text: "Додав ще одне джерело доходу до основного фрілансу. Тепер AI-персонаж приносить більше ніж моя основна робота.",
      avatar: "ДЛ",
      stars: 5,
    },
  ];

  return (
    <section
      id="results"
      style={{
        padding: "100px 24px",
        background: "#0A0A0A",
      }}
    >
      <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "64px" }}>
          <div className="orange-badge" style={{ marginBottom: "16px" }}>
            Вже працюють після курсу
          </div>
          <h2 className="section-title">
            Результати наших{" "}
            <span className="orange-text">студентів</span>
          </h2>
        </div>

        {/* Stats row */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: "24px",
            marginBottom: "64px",
          }}
        >
          {[
            { val: "500+", label: "Студентів пройшли" },
            { val: "$2.8К", label: "Середній дохід" },
            { val: "94%", label: "Задоволених учнів" },
            { val: "30", label: "Днів до результату" },
          ].map((stat) => (
            <div
              key={stat.label}
              style={{
                background: "#111",
                border: "1px solid rgba(255,107,0,0.15)",
                borderRadius: "16px",
                padding: "28px",
                textAlign: "center",
              }}
            >
              <div
                style={{
                  fontFamily: "Bebas Neue, sans-serif",
                  fontSize: "44px",
                  color: "#FF6B00",
                  lineHeight: "1",
                  marginBottom: "8px",
                }}
              >
                {stat.val}
              </div>
              <div
                style={{
                  fontSize: "13px",
                  color: "rgba(255,255,255,0.5)",
                  fontWeight: "600",
                }}
              >
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
            gap: "24px",
          }}
        >
          {testimonials.map((t) => (
            <div key={t.name} className="testimonial-card">
              <div
                style={{
                  padding: "28px",
                  borderBottom: "1px solid rgba(255,255,255,0.05)",
                  background: "rgba(255,107,0,0.04)",
                }}
              >
                <div style={{ display: "flex", gap: "4px", marginBottom: "16px" }}>
                  {Array.from({ length: t.stars }).map((_, i) => (
                    <span key={i} className="star">★</span>
                  ))}
                </div>
                <p
                  style={{
                    fontSize: "14px",
                    color: "rgba(255,255,255,0.75)",
                    lineHeight: "1.7",
                    fontStyle: "italic",
                  }}
                >
                  &ldquo;{t.text}&rdquo;
                </p>
              </div>
              <div
                style={{
                  padding: "20px 28px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                  <div
                    style={{
                      width: "44px",
                      height: "44px",
                      background: "linear-gradient(135deg, #FF6B00, #FF8C00)",
                      borderRadius: "50%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "14px",
                      fontWeight: "800",
                      color: "white",
                    }}
                  >
                    {t.avatar}
                  </div>
                  <div>
                    <div style={{ fontWeight: "700", fontSize: "14px" }}>
                      {t.name}
                    </div>
                    <div
                      style={{
                        fontSize: "12px",
                        color: "rgba(255,255,255,0.4)",
                      }}
                    >
                      {t.role}
                    </div>
                  </div>
                </div>
                <div
                  style={{
                    background: "rgba(255,107,0,0.12)",
                    border: "1px solid rgba(255,107,0,0.3)",
                    borderRadius: "8px",
                    padding: "6px 14px",
                    fontSize: "14px",
                    fontWeight: "800",
                    color: "#FF6B00",
                  }}
                >
                  {t.income}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Car / luxury lifestyle teaser */}
        <div
          style={{
            marginTop: "64px",
            background: "linear-gradient(135deg, #0f0a00, #1a0e00)",
            border: "1px solid rgba(255,107,0,0.2)",
            borderRadius: "20px",
            padding: "48px",
            textAlign: "center",
            position: "relative",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              background: "radial-gradient(circle at center, rgba(255,107,0,0.08) 0%, transparent 70%)",
            }}
          />
          <div style={{ position: "relative" }}>
            <div style={{ fontSize: "40px", marginBottom: "16px" }}>🏎️</div>
            <h3
              style={{
                fontFamily: "Montserrat, sans-serif",
                fontWeight: "800",
                fontSize: "clamp(22px, 3vw, 36px)",
                color: "white",
                marginBottom: "16px",
              }}
            >
              Уяви собі:{" "}
              <span className="orange-text">цей рівень життя</span> доступний тобі
            </h3>
            <p
              style={{
                color: "rgba(255,255,255,0.55)",
                fontSize: "15px",
                maxWidth: "560px",
                margin: "0 auto 32px",
                lineHeight: "1.7",
              }}
            >
              Наші студенти вже досягають фінансової свободи. Час вирватись зі
              звичного і почати будувати своє майбутнє.
            </p>
            <a href="#payment" className="btn-primary" style={{ fontSize: "15px" }}>
              Почати свій шлях →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
