"use client";
import { useState } from "react";

export default function GuaranteeFAQ() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const faqs = [
    {
      q: "Чи потрібен попередній досвід?",
      a: "Ні! Курс розроблений для повних початківців. Ми починаємо з нуля та поступово пояснюємо кожен крок. Достатньо мати смартфон або комп'ютер та бажання вчитись.",
    },
    {
      q: "Скільки часу потрібно приділяти навчанню?",
      a: "Достатньо 1-2 години на день. Курс розрахований на 30 днів, але ви маєте довічний доступ і можете проходити у власному темпі.",
    },
    {
      q: "Коли можна очікувати перший дохід?",
      a: "Більшість студентів отримують перший дохід вже на 2-3 тижні навчання. Серйозні результати ($1К+/міс) зазвичай приходять через 30-60 днів активної роботи.",
    },
    {
      q: "Що якщо мені не підійде курс?",
      a: "Ми надаємо 14-денну гарантію повернення коштів. Якщо курс вам не підійшов — просто напишіть нам, і ми повернемо 100% оплати без зайвих питань.",
    },
    {
      q: "Чи є підтримка після курсу?",
      a: "Так! Студенти отримують доступ до закритого ком'юніті назавжди. Преміум-студенти також мають особистого куратора протягом 3 місяців.",
    },
  ];

  return (
    <>
      {/* Guarantee section */}
      <section
        style={{
          padding: "80px 24px",
          background: "#080808",
        }}
      >
        <div style={{ maxWidth: "900px", margin: "0 auto" }}>
          <div
            style={{
              background: "linear-gradient(135deg, #0f1a0f, #0a150a)",
              border: "1px solid rgba(50,200,50,0.2)",
              borderRadius: "24px",
              padding: "56px",
              display: "flex",
              gap: "40px",
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            <div
              style={{
                width: "100px",
                height: "100px",
                background: "rgba(50,200,50,0.1)",
                border: "2px solid rgba(50,200,50,0.3)",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "44px",
                flexShrink: 0,
              }}
            >
              🛡️
            </div>
            <div>
              <h2
                style={{
                  fontFamily: "Montserrat, sans-serif",
                  fontWeight: "800",
                  fontSize: "clamp(24px, 3vw, 36px)",
                  color: "white",
                  marginBottom: "16px",
                }}
              >
                Гарантія{" "}
                <span style={{ color: "#4ade80" }}>14 днів</span>
              </h2>
              <p
                style={{
                  color: "rgba(255,255,255,0.6)",
                  fontSize: "15px",
                  lineHeight: "1.7",
                  maxWidth: "500px",
                }}
              >
                Ми настільки впевнені в якості курсу, що готові повернути 100%
                коштів протягом 14 днів, якщо ти не задоволений результатом.
                Жодних питань та бюрократії — просто написати нам.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section
        style={{
          padding: "80px 24px 120px",
          background: "#0A0A0A",
        }}
      >
        <div style={{ maxWidth: "800px", margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: "52px" }}>
            <div className="orange-badge" style={{ marginBottom: "16px" }}>
              Питання?
            </div>
            <h2 className="section-title">
              Часті <span className="orange-text">запитання</span>
            </h2>
          </div>

          <div
            style={{
              background: "#111",
              border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: "20px",
              overflow: "hidden",
            }}
          >
            {faqs.map((faq, i) => (
              <div
                key={i}
                className="faq-item"
                style={{
                  borderBottom: i < faqs.length - 1 ? "1px solid rgba(255,255,255,0.07)" : "none",
                  padding: "0",
                }}
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
              >
                <div
                  style={{
                    padding: "24px 28px",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: "20px",
                  }}
                >
                  <span
                    style={{
                      fontWeight: "600",
                      fontSize: "15px",
                      color: "white",
                    }}
                  >
                    {faq.q}
                  </span>
                  <div
                    style={{
                      width: "32px",
                      height: "32px",
                      background: openFaq === i ? "#FF6B00" : "rgba(255,107,0,0.1)",
                      border: "1px solid rgba(255,107,0,0.3)",
                      borderRadius: "8px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                      transition: "all 0.3s ease",
                      transform: openFaq === i ? "rotate(45deg)" : "rotate(0deg)",
                    }}
                  >
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                      <path
                        d="M7 2V12M2 7H12"
                        stroke={openFaq === i ? "white" : "#FF6B00"}
                        strokeWidth="2"
                        strokeLinecap="round"
                      />
                    </svg>
                  </div>
                </div>
                {openFaq === i && (
                  <div
                    style={{
                      padding: "0 28px 24px",
                      fontSize: "14px",
                      color: "rgba(255,255,255,0.6)",
                      lineHeight: "1.7",
                    }}
                  >
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
