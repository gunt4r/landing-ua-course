"use client";
import { useEffect, useState } from "react";

export default function Hero() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <section
      style={{
        minHeight: "100vh",
        background:
          "linear-gradient(135deg, #0A0A0A 0%, #0F0A00 50%, #0A0A0A 100%)",
        position: "relative",
        overflow: "hidden",
        display: "flex",
        alignItems: "center",
        paddingTop: "80px",
      }}
    >
      {/* Background glow */}
      <div
        style={{
          position: "absolute",
          top: "20%",
          right: "-10%",
          width: "600px",
          height: "600px",
          background:
            "radial-gradient(circle, rgba(255,107,0,0.12) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "absolute",
          bottom: "10%",
          left: "-5%",
          width: "400px",
          height: "400px",
          background:
            "radial-gradient(circle, rgba(255,107,0,0.06) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "60px 24px",
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "60px",
          alignItems: "center",
          position: "relative",
          zIndex: 1,
        }}
      >
        {/* Left content */}
        <div
          style={{
            opacity: mounted ? 1 : 0,
            transform: mounted ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.8s ease",
          }}
        >
          <div className="orange-badge" style={{ marginBottom: "20px" }}>
            🔥 Нова можливість
          </div>

          <h1
            style={{
              fontFamily: "Montserrat, sans-serif",
              fontWeight: "900",
              fontSize: "clamp(32px, 4.5vw, 56px)",
              lineHeight: "1.1",
              color: "white",
              marginBottom: "24px",
            }}
          >
            Як створити{" "}
            <span style={{ color: "#FF6B00" }}>Анінфлюенсера</span>{" "}
            та заробляти від{" "}
            <span
              style={{
                color: "#FF6B00",
                display: "inline-block",
                background: "rgba(255,107,0,0.1)",
                padding: "0 8px",
                borderRadius: "6px",
                border: "1px solid rgba(255,107,0,0.3)",
              }}
            >
              $2500
            </span>{" "}
            на місяць на донатах і рекламі 🚀
          </h1>

          <p
            style={{
              color: "rgba(255,255,255,0.65)",
              fontSize: "16px",
              lineHeight: "1.7",
              marginBottom: "36px",
              maxWidth: "480px",
            }}
          >
            Повний практичний курс від нуля до першого доходу. Без досвіду,
            без великої аудиторії — тільки перевірені методи та реальні
            результати.
          </p>

          {/* Stats */}
          <div
            style={{
              display: "flex",
              gap: "32px",
              marginBottom: "40px",
            }}
          >
            {[
              { value: "500+", label: "Студентів" },
              { value: "$2.5К+", label: "Середній дохід" },
              { value: "30", label: "Днів курсу" },
            ].map((stat) => (
              <div key={stat.label}>
                <div
                  style={{
                    fontFamily: "Bebas Neue, sans-serif",
                    fontSize: "32px",
                    color: "#FF6B00",
                    lineHeight: "1",
                  }}
                >
                  {stat.value}
                </div>
                <div
                  style={{
                    fontSize: "12px",
                    color: "rgba(255,255,255,0.5)",
                    textTransform: "uppercase",
                    letterSpacing: "1px",
                    marginTop: "4px",
                  }}
                >
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
            <a href="#payment" className="btn-primary" style={{ fontSize: "15px", padding: "16px 40px" }}>
              Розпочати зараз
            </a>
            <a href="#about" className="btn-secondary" style={{ fontSize: "15px", padding: "16px 40px" }}>
              Дізнатись більше
            </a>
          </div>

          {/* Bonus badge */}
          <div
            style={{
              marginTop: "28px",
              padding: "14px 20px",
              background: "rgba(255,107,0,0.08)",
              border: "1px solid rgba(255,107,0,0.25)",
              borderRadius: "12px",
              display: "inline-flex",
              alignItems: "center",
              gap: "10px",
            }}
          >
            <span style={{ fontSize: "20px" }}>🎁</span>
            <span style={{ fontSize: "13px", color: "rgba(255,255,255,0.8)" }}>
              При реєстрації сьогодні —{" "}
              <strong style={{ color: "#FF6B00" }}>бонус безкоштовно</strong>
            </span>
          </div>
        </div>

        {/* Right content - Person + Phone mockup */}
        <div
          style={{
            position: "relative",
            display: "flex",
            justifyContent: "center",
            opacity: mounted ? 1 : 0,
            transform: mounted ? "translateX(0)" : "translateX(30px)",
            transition: "all 0.8s ease 0.3s",
          }}
        >
          {/* Decorative circles */}
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%,-50%)",
              width: "400px",
              height: "400px",
              border: "1px solid rgba(255,107,0,0.15)",
              borderRadius: "50%",
            }}
          />
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%,-50%)",
              width: "500px",
              height: "500px",
              border: "1px solid rgba(255,107,0,0.07)",
              borderRadius: "50%",
            }}
          />

          {/* Main visual card */}
          <div
            style={{
              background: "linear-gradient(145deg, #1a1a1a, #111)",
              border: "1px solid rgba(255,107,0,0.2)",
              borderRadius: "24px",
              padding: "40px",
              width: "100%",
              maxWidth: "440px",
              position: "relative",
              zIndex: 1,
            }}
            className="animate-float"
          >
            {/* Mock phone UI */}
            <div
              style={{
                background: "#0A0A0A",
                borderRadius: "18px",
                padding: "20px",
                marginBottom: "20px",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: "16px",
                }}
              >
                <span
                  style={{
                    fontSize: "12px",
                    color: "rgba(255,255,255,0.5)",
                    fontWeight: "600",
                  }}
                >
                  Доходи за місяць
                </span>
                <span
                  style={{
                    fontSize: "12px",
                    color: "#FF6B00",
                    fontWeight: "700",
                  }}
                >
                  +47%
                </span>
              </div>

              {/* Bar chart mock */}
              <div
                style={{
                  display: "flex",
                  alignItems: "flex-end",
                  gap: "8px",
                  height: "80px",
                }}
              >
                {[40, 60, 45, 80, 65, 90, 75, 100, 85, 95].map(
                  (h, i) => (
                    <div
                      key={i}
                      style={{
                        flex: 1,
                        height: `${h}%`,
                        background:
                          i === 9
                            ? "linear-gradient(180deg, #FF6B00, #FF8C00)"
                            : `rgba(255,107,0,${0.2 + i * 0.05})`,
                        borderRadius: "4px 4px 0 0",
                        transition: "height 0.5s ease",
                      }}
                    />
                  )
                )}
              </div>
            </div>

            {/* Income display */}
            <div
              style={{
                background: "linear-gradient(135deg, rgba(255,107,0,0.15), rgba(255,107,0,0.05))",
                border: "1px solid rgba(255,107,0,0.3)",
                borderRadius: "14px",
                padding: "20px",
                textAlign: "center",
                marginBottom: "16px",
              }}
            >
              <div
                style={{
                  fontSize: "12px",
                  color: "rgba(255,255,255,0.5)",
                  marginBottom: "8px",
                  textTransform: "uppercase",
                  letterSpacing: "1px",
                }}
              >
                Заробіток цього місяця
              </div>
              <div
                style={{
                  fontFamily: "Bebas Neue, sans-serif",
                  fontSize: "52px",
                  color: "#FF6B00",
                  lineHeight: "1",
                }}
              >
                $3,164.20
              </div>
            </div>

            {/* Notification items */}
            {[
              { text: "Новий донат +$45 🎉", time: "2хв" },
              { text: "Реклама оплачена +$320", time: "1год" },
              { text: "Підписник приєднався", time: "5хв" },
            ].map((notif) => (
              <div key={notif.text} className="notification-item">
                <div
                  style={{
                    width: "32px",
                    height: "32px",
                    background: "rgba(255,107,0,0.15)",
                    borderRadius: "8px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "14px",
                    flexShrink: 0,
                  }}
                >
                  💰
                </div>
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      fontSize: "12px",
                      color: "rgba(255,255,255,0.85)",
                      fontWeight: "600",
                    }}
                  >
                    {notif.text}
                  </div>
                </div>
                <div
                  style={{
                    fontSize: "10px",
                    color: "rgba(255,255,255,0.3)",
                  }}
                >
                  {notif.time}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
