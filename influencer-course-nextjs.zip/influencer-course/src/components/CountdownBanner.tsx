"use client";
import { useState, useEffect } from "react";

export default function CountdownBanner() {
  const [time, setTime] = useState({ hours: 3, minutes: 12, seconds: 0 });

  useEffect(() => {
    const interval = setInterval(() => {
      setTime((prev) => {
        let { hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) { seconds = 59; minutes--; }
        if (minutes < 0) { minutes = 59; hours--; }
        if (hours < 0) { hours = 23; }
        return { hours, minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const pad = (n: number) => n.toString().padStart(2, "0");

  return (
    <section
      style={{
        background: "linear-gradient(135deg, #1a0a00, #0f0a00)",
        borderTop: "1px solid rgba(255,107,0,0.2)",
        borderBottom: "1px solid rgba(255,107,0,0.2)",
        padding: "40px 24px",
      }}
    >
      <div
        style={{
          maxWidth: "1000px",
          margin: "0 auto",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "40px",
          flexWrap: "wrap",
        }}
      >
        <div>
          <div
            style={{
              fontFamily: "Montserrat, sans-serif",
              fontWeight: "800",
              fontSize: "clamp(20px, 3vw, 32px)",
              color: "white",
              marginBottom: "8px",
            }}
          >
            🔥 Не втрачайте цю пропозицію
          </div>
          <p style={{ color: "rgba(255,255,255,0.6)", fontSize: "14px" }}>
            Ціна зростає через:
          </p>
        </div>

        {/* Countdown */}
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <div className="countdown-block">
            <span className="countdown-number">{pad(time.hours)}</span>
            <span className="countdown-label">Год</span>
          </div>
          <div
            style={{
              fontFamily: "Bebas Neue, sans-serif",
              fontSize: "40px",
              color: "#FF6B00",
            }}
          >
            :
          </div>
          <div className="countdown-block">
            <span className="countdown-number">{pad(time.minutes)}</span>
            <span className="countdown-label">Хв</span>
          </div>
          <div
            style={{
              fontFamily: "Bebas Neue, sans-serif",
              fontSize: "40px",
              color: "#FF6B00",
            }}
          >
            :
          </div>
          <div className="countdown-block">
            <span className="countdown-number">{pad(time.seconds)}</span>
            <span className="countdown-label">Сек</span>
          </div>
        </div>

        <a href="#payment" className="btn-primary animate-pulse-glow">
          Забрати місце
        </a>
      </div>
    </section>
  );
}
