# AniFluence — Influencer Course Landing Page

A full Next.js 14 TypeScript landing page for an AI influencer course, built with Tailwind CSS.

## Tech Stack

- **Next.js 14** (App Router)
- **TypeScript**
- **Tailwind CSS**
- **Google Fonts** (Bebas Neue + Montserrat)

## Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Build for Production

```bash
npm run build
npm start
```

## Project Structure

```
src/
├── app/
│   ├── globals.css        # Global styles, CSS variables, animations
│   ├── layout.tsx         # Root layout with Google Fonts
│   └── page.tsx           # Main page composing all sections
└── components/
    ├── Header.tsx          # Sticky nav with scroll effect
    ├── Hero.tsx            # Hero section with income mockup
    ├── CountdownBanner.tsx # Live countdown timer
    ├── About.tsx           # Why this course / income types
    ├── ForWhom.tsx         # Target audience section
    ├── Results.tsx         # Student testimonials & stats
    ├── Program.tsx         # Course curriculum (6 modules)
    ├── Payment.tsx         # Pricing plans + bonuses
    ├── GuaranteeFAQ.tsx    # Guarantee + accordion FAQ
    └── FinalCTA.tsx        # Final call-to-action + footer
```

## Design System

- **Colors**: Dark bg (`#0A0A0A`), Orange accent (`#FF6B00`)
- **Fonts**: Bebas Neue (display), Montserrat (body)
- **Theme**: Dark, energetic, Ukrainian-language content
- **Animations**: Float, pulse-glow, fade-in-up
