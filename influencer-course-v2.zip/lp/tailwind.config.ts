import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        accent: {
          DEFAULT: "#FF6A00",
          light:   "#FF8533",
          dark:    "#CC5500",
          glow:    "rgba(255,106,0,0.35)",
        },
        surface: {
          DEFAULT: "#111111",
          hover:   "#161616",
          card:    "#0E0E0E",
          border:  "rgba(255,255,255,0.07)",
        },
      },
      fontFamily: {
        display: ["var(--font-syne)", "sans-serif"],
        body:    ["var(--font-dm-sans)", "sans-serif"],
        mono:    ["var(--font-jetbrains)", "monospace"],
      },
      backgroundImage: {
        "accent-gradient": "linear-gradient(135deg, #FF6A00 0%, #CC5500 100%)",
        "hero-gradient":   "radial-gradient(ellipse 80% 60% at 50% 0%, rgba(255,106,0,0.12) 0%, transparent 70%)",
        "card-gradient":   "linear-gradient(145deg, rgba(255,106,0,0.06) 0%, transparent 60%)",
        "glow-radial":     "radial-gradient(circle, rgba(255,106,0,0.2) 0%, transparent 70%)",
      },
      boxShadow: {
        "accent-sm":  "0 0 16px rgba(255,106,0,0.25)",
        "accent-md":  "0 0 32px rgba(255,106,0,0.35)",
        "accent-lg":  "0 0 60px rgba(255,106,0,0.45)",
        "accent-btn": "0 4px 24px rgba(255,106,0,0.4), 0 1px 0 rgba(255,255,255,0.1) inset",
        "card":       "0 1px 0 rgba(255,255,255,0.05) inset, 0 20px 40px rgba(0,0,0,0.4)",
      },
      borderRadius: {
        "2xl": "1rem",
        "3xl": "1.25rem",
        "4xl": "1.5rem",
      },
      animation: {
        "pulse-slow":    "pulse 3s cubic-bezier(0.4,0,0.6,1) infinite",
        "glow-pulse":    "glowPulse 2.5s ease-in-out infinite",
        "float":         "float 4s ease-in-out infinite",
        "gradient-shift":"gradientShift 6s ease infinite",
        "count-up":      "countUp 0.8s ease forwards",
      },
      keyframes: {
        glowPulse: {
          "0%,100%": { boxShadow: "0 0 20px rgba(255,106,0,0.3)" },
          "50%":     { boxShadow: "0 0 50px rgba(255,106,0,0.6)" },
        },
        float: {
          "0%,100%": { transform: "translateY(0px)"  },
          "50%":     { transform: "translateY(-8px)"  },
        },
        gradientShift: {
          "0%,100%": { backgroundPosition: "0% 50%"   },
          "50%":     { backgroundPosition: "100% 50%" },
        },
        countUp: {
          from: { opacity: "0", transform: "translateY(8px)" },
          to:   { opacity: "1", transform: "translateY(0)"   },
        },
      },
      transitionTimingFunction: {
        "spring": "cubic-bezier(0.34, 1.56, 0.64, 1)",
      },
    },
  },
  plugins: [],
};

export default config;
