import type { Metadata, Viewport } from "next";
import "@/styles/globals.css";

export const metadata: Metadata = {
  title: "AniFluence — Створи AI-модель і заробляй від $2500/міс",
  description:
    "Повний онлайн-курс: робочі кейси, шаблони та підтримка. Стань анінфлюенсером та монетизуй контент через донати і рекламу.",
  keywords: ["AI модель", "анінфлюенсер", "заробіток онлайн", "курс", "стримінг", "донати"],
  authors: [{ name: "AniFluence" }],
  openGraph: {
    title: "AniFluence — Заробляй від $2500 на місяць",
    description: "Повний онлайн-курс зі створення AI-персонажа та монетизації контенту.",
    type: "website",
    locale: "uk_UA",
    siteName: "AniFluence",
  },
  twitter: {
    card: "summary_large_image",
    title: "AniFluence — AI модель та заробіток від $2500/міс",
    description: "Повний онлайн-курс. Без досвіду. Результат за 30 днів.",
  },
  robots: { index: true, follow: true },
  alternates: { canonical: "https://anifluence.com" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#000000",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="uk">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=JetBrains+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        {/* Noise texture overlay for premium feel */}
        <div className="noise-overlay" aria-hidden="true" />
        {children}
      </body>
    </html>
  );
}
