import Header     from "@/components/layout/Header";
import StickyCTA  from "@/components/layout/StickyCTA";
import Footer     from "@/components/layout/Footer";

import Hero        from "@/components/sections/Hero";
import SocialProof from "@/components/sections/SocialProof";
import About       from "@/components/sections/About";
import ForWhom     from "@/components/sections/ForWhom";
import Results     from "@/components/sections/Results";
import Program     from "@/components/sections/Program";
import Payment     from "@/components/sections/Payment";
import AfterCourse from "@/components/sections/AfterCourse";
import Guarantee   from "@/components/sections/Guarantee";
import FAQ         from "@/components/sections/FAQ";
import FinalCTA    from "@/components/sections/FinalCTA";

export default function Home() {
  return (
    <>
      <Header />

      <main>
        <Hero />
        <SocialProof />
        <About />
        <ForWhom />
        <Results />
        <Program />
        <Payment />
        <AfterCourse />
        <Guarantee />
        <FAQ />
        <FinalCTA />
      </main>

      <Footer />

      {/* Mobile sticky CTA — shown only on mobile via CSS */}
      <StickyCTA />
    </>
  );
}
