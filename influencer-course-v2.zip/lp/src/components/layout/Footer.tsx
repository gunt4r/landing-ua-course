export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer style={{
      background: "#050505",
      padding: "40px 24px",
      borderTop: "1px solid rgba(255,106,0,0.08)",
    }}>
      <div className="container" style={{
        display: "flex", justifyContent: "space-between",
        alignItems: "center", flexWrap: "wrap", gap: 20,
      }}>
        {/* Logo */}
        <a href="#" style={{ display: "flex", alignItems: "center", gap: 9, textDecoration: "none" }}>
          <div style={{
            width: 34, height: 34,
            background: "linear-gradient(135deg,#FF6A00,#CC5500)",
            borderRadius: 8, display: "flex", alignItems: "center",
            justifyContent: "center", fontWeight: 900, fontSize: 17, color: "#fff",
            boxShadow: "0 0 12px rgba(255,106,0,0.3)",
          }}>А</div>
          <span className="font-display" style={{ fontSize: 16 }}>
            ANI<span style={{ color: "#FF6A00" }}>FLUENCE</span>
          </span>
        </a>

        <nav style={{ display: "flex", gap: 22, flexWrap: "wrap" }}>
          {["Умови використання","Політика конфіденційності","Повернення коштів"].map(l=>(
            <a key={l} href="#" style={{
              fontSize: 13, color: "rgba(255,255,255,0.32)", textDecoration: "none",
              transition: "color 0.2s",
            }}
              onMouseEnter={e=>(e.currentTarget.style.color="rgba(255,106,0,0.8)")}
              onMouseLeave={e=>(e.currentTarget.style.color="rgba(255,255,255,0.32)")}
            >{l}</a>
          ))}
        </nav>

        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.2)" }}>
          © {year} AniFluence. Всі права захищені.
        </p>
      </div>
    </footer>
  );
}
