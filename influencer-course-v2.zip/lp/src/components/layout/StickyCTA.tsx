"use client";
import { motion } from "framer-motion";

export default function StickyCTA() {
  return (
    <motion.div
      className="sticky-cta-mobile"
      initial={{ y: 80 }}
      animate={{ y: 0 }}
      transition={{ delay: 1.2, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Price info */}
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.45)", textTransform: "uppercase", letterSpacing: "1px" }}>Курс від</div>
        <div style={{ fontSize: 20, fontWeight: 800, color: "#FF6A00", lineHeight: 1.1 }}>$197</div>
      </div>

      {/* CTA */}
      <a
        href="#payment"
        className="btn-primary animate-glow-pulse"
        style={{ flex: 2, justifyContent: "center", minHeight: 52, fontSize: 16 }}
      >
        🚀 Купити курс
      </a>
    </motion.div>
  );
}
