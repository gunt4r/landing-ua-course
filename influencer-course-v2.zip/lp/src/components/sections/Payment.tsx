"use client";
import { motion } from "framer-motion";
import { staggerContainer, fadeUp } from "@/lib/motion";
import MotionSection from "@/components/ui/MotionSection";
import CTAButton from "@/components/ui/CTAButton";

const BONUSES = [
  { icon: "📱", t: "Чат-бот для збору донатів",  v: "$197" },
  { icon: "📊", t: "Шаблони медіакітів та угод", v: "$97"  },
  { icon: "🎯", t: "База рекламодавців 200+",     v: "$147" },
  { icon: "🤖", t: "AI-промпти для контенту",    v: "$67"  },
  { icon: "🎓", t: "Менторська сесія 60хв",       v: "$150" },
  { icon: "📹", t: "Техніка монтажу відео",       v: "$89"  },
];

const CHECK = ({ text }: { text: string }) => (
  <div className="check-item">
    <div className="check-dot">
      <svg width="9" height="7" viewBox="0 0 9 7" fill="none">
        <path d="M1 3.5L3.5 6L8 1" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
    {text}
  </div>
);

export default function Payment() {
  return (
    <section id="payment" style={{
      padding: "90px 0",
      background: "linear-gradient(180deg,#000,#080500,#000)",
      position: "relative", overflow: "hidden",
    }}>
      <div className="glow-orb" style={{ width: 700, height: 500, top: "50%", left: "50%", transform: "translate(-50%,-50%)", background: "rgba(255,106,0,0.04)", filter: "blur(100px)" }} />

      <div className="container" style={{ position: "relative" }}>
        {/* Header */}
        <MotionSection style={{ marginBottom: 52 } as React.CSSProperties}>
          <div style={{
            background: "linear-gradient(135deg,#100700,#180b00)",
            border: "1px solid rgba(255,106,0,0.2)",
            borderRadius: 22, padding: "38px 46px",
            display: "grid", gridTemplateColumns: "1fr auto",
            gap: 32, alignItems: "center", overflow: "hidden",
          }}>
            <div>
              <span className="section-pill" style={{ marginBottom: 16, display: "inline-flex" }}>Здійсни оплату зараз та отримай усі бонуси</span>
              <h2 className="font-display" style={{ fontSize: "clamp(26px,4vw,46px)", fontWeight: 800, marginBottom: 12 }}>
                Обери свій <span style={{ color: "#FF6A00" }}>тарифний план</span>
              </h2>
              <p style={{ color: "rgba(255,255,255,0.48)", fontSize: 14, lineHeight: 1.7 }}>
                При оплаті сьогодні ти отримуєш бонуси на суму{" "}
                <strong style={{ color: "#FF6A00" }}>$747 безкоштовно</strong>
              </p>
            </div>
            <motion.div
              animate={{ rotate: [-5, 5, -5], y: [0, -8, 0] }}
              transition={{ duration: 3, ease: "easeInOut", repeat: Infinity }}
              className="hide-mobile"
              style={{ fontSize: 96, filter: "drop-shadow(0 10px 30px rgba(255,106,0,0.3))" }}
            >🚀</motion.div>
          </div>
        </MotionSection>

        {/* Pricing cards */}
        <motion.div
          variants={staggerContainer(0.15)}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
          style={{ display: "grid", gridTemplateColumns: "1fr 1.05fr", gap: 22, marginBottom: 54 }}
        >
          {/* Basic */}
          <motion.div variants={fadeUp}>
            <div style={{
              background: "#0E0E0E", border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 22, padding: 36, height: "100%",
            }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "1.2px", marginBottom: 16 }}>Базовий</div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginBottom: 4 }}>
                <span className="font-display" style={{ fontSize: 58, color: "#fff", lineHeight: 1 }}>$197</span>
                <span style={{ fontSize: 18, color: "rgba(255,255,255,0.28)", textDecoration: "line-through" }}>$397</span>
              </div>
              <div style={{
                display: "inline-block", background: "rgba(50,200,80,0.12)", border: "1px solid rgba(50,200,80,0.28)",
                borderRadius: 6, padding: "2px 10px", fontSize: 12, color: "#4ade80", fontWeight: 700, marginBottom: 28,
              }}>Знижка 50%</div>
              <div style={{ marginBottom: 32 }}>
                {["Доступ до всіх 57 уроків","Закрите ком'юніті","Сертифікат про проходження","Підтримка 2 місяці"].map(f=><CHECK key={f} text={f}/>)}
              </div>
              <CTAButton variant="ghost" size="md" style={{ width: "100%" } as React.CSSProperties}>Вибрати базовий</CTAButton>
            </div>
          </motion.div>

          {/* Premium */}
          <motion.div variants={fadeUp}>
            <div style={{
              background: "linear-gradient(160deg,#1a0c00,#100800)",
              border: "2px solid #FF6A00", borderRadius: 22, padding: 36, height: "100%",
              position: "relative",
              boxShadow: "0 0 60px rgba(255,106,0,0.15)",
            }}>
              <div style={{
                position: "absolute", top: -15, left: "50%", transform: "translateX(-50%)",
                background: "linear-gradient(135deg,#FF6A00,#CC5500)",
                color: "#fff", fontSize: 12, fontWeight: 700,
                padding: "6px 24px", borderRadius: 20, whiteSpace: "nowrap",
                boxShadow: "0 6px 20px rgba(255,106,0,0.35)",
              }}>🔥 НАЙПОПУЛЯРНІШИЙ</div>

              <div style={{ fontSize: 11, fontWeight: 700, color: "#FF6A00", textTransform: "uppercase", letterSpacing: "1.2px", marginBottom: 16 }}>Преміум</div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginBottom: 4 }}>
                <span className="font-display" style={{ fontSize: 58, color: "#FF6A00", lineHeight: 1 }}>$397</span>
                <span style={{ fontSize: 18, color: "rgba(255,255,255,0.28)", textDecoration: "line-through" }}>$797</span>
              </div>
              <div style={{
                display: "inline-block", background: "rgba(255,106,0,0.12)", border: "1px solid rgba(255,106,0,0.28)",
                borderRadius: 6, padding: "2px 10px", fontSize: 12, color: "#FF6A00", fontWeight: 700, marginBottom: 28,
              }}>Знижка 50% + всі бонуси</div>
              <div style={{ marginBottom: 32 }}>
                {["Все з базового тарифу","Особистий куратор 3 місяці","Зворотній зв'язок по контенту","Закриті вебінари","Усі 6 бонусних матеріалів","Безмежна підтримка в чаті"].map(f=><CHECK key={f} text={f}/>)}
              </div>
              <CTAButton size="md" pulse style={{ width: "100%", fontSize: "16px" } as React.CSSProperties}>
                Отримати преміум доступ
              </CTAButton>
            </div>
          </motion.div>
        </motion.div>

        {/* Bonuses */}
        <MotionSection>
          <h3 className="font-display" style={{ fontSize: "clamp(18px,2.5vw,26px)", textAlign: "center", marginBottom: 28 }}>
            🎁 Бонуси при оплаті сьогодні —{" "}
            <span style={{ color: "#FF6A00" }}>$747 безкоштовно</span>
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 15 }}>
            {BONUSES.map(({ icon, t, v }) => (
              <motion.div
                key={t}
                whileHover={{ borderColor: "rgba(255,106,0,0.32)", background: "#141414" }}
                style={{
                  background: "#0E0E0E", border: "1px solid rgba(255,106,0,0.12)",
                  borderRadius: 14, padding: "16px 18px",
                  display: "flex", gap: 13, alignItems: "center",
                  transition: "background 0.2s",
                }}
              >
                <span style={{ fontSize: 28, flexShrink: 0 }}>{icon}</span>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 3 }}>{t}</div>
                  <div style={{ fontSize: 13, fontWeight: 800, color: "#FF6A00" }}>Вартість: {v}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </MotionSection>

        {/* TREND */}
        <MotionSection style={{ marginTop: 64 } as React.CSSProperties}>
          <div style={{
            background: "#0A0A0A", border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 22, padding: "44px 48px",
            display: "grid", gridTemplateColumns: "auto 1fr",
            gap: 48, alignItems: "center",
          }}>
            <div style={{ textAlign: "center" }}>
              <div className="font-display animate-shimmer-text" style={{ fontSize: "clamp(46px,7vw,78px)", letterSpacing: 3, lineHeight: 1 }}>
                ТРЕНД
              </div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.32)", marginTop: 4, letterSpacing: 2, textTransform: "uppercase" }}>
                поки ти проходиш
              </div>
            </div>
            <div>
              <h3 className="font-display" style={{ fontSize: "clamp(18px,2.5vw,26px)", marginBottom: 12 }}>
                Анінфлюенсери — найгарячіший тренд <span style={{ color: "#FF6A00" }}>2024–2025</span>
              </h3>
              <p style={{ color: "rgba(255,255,255,0.48)", fontSize: 14, lineHeight: 1.72 }}>
                Ринок тільки формується. Ті, хто стартують сьогодні — виграють. Не чекай.
              </p>
            </div>
          </div>
        </MotionSection>
      </div>
    </section>
  );
}
