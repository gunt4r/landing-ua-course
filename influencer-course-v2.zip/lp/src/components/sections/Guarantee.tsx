"use client";
import { motion } from "framer-motion";
import MotionSection from "@/components/ui/MotionSection";

export default function Guarantee() {
  return (
    <section style={{ padding: "80px 0", background: "#080808" }}>
      <div className="container">
        <MotionSection>
          <div style={{
            background: "linear-gradient(135deg,#080e08,#0a120a)",
            border: "1px solid rgba(50,200,50,0.2)",
            borderRadius: 22, padding: "52px 52px",
            display: "grid", gridTemplateColumns: "auto 1fr",
            gap: 40, alignItems: "center",
          }}>
            <motion.div
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 3, ease: "easeInOut", repeat: Infinity }}
              style={{
                width: 110, height: 110,
                background: "rgba(50,200,50,0.07)", border: "2px solid rgba(50,200,50,0.22)",
                borderRadius: "50%", display: "flex", alignItems: "center",
                justifyContent: "center", fontSize: 48, flexShrink: 0,
              }}
            >🛡️</motion.div>

            <div>
              <div style={{
                display: "inline-block",
                background: "rgba(50,200,50,0.1)", border: "1px solid rgba(50,200,50,0.25)",
                color: "#4ade80", fontSize: 11, fontWeight: 700, letterSpacing: "1.5px",
                textTransform: "uppercase", padding: "4px 14px", borderRadius: 20, marginBottom: 14,
              }}>Гарантія</div>

              <h2 className="font-display" style={{ fontSize: "clamp(24px,3.5vw,42px)", fontWeight: 800, marginBottom: 16 }}>
                Гарантія повернення{" "}
                <span style={{ color: "#4ade80" }}>14 днів</span>
              </h2>
              <p style={{ color: "rgba(255,255,255,0.54)", fontSize: 15, lineHeight: 1.72, maxWidth: 580 }}>
                Ми настільки впевнені в якості курсу, що готові повернути{" "}
                <strong style={{ color: "#fff" }}>100% коштів</strong> протягом 14 днів, якщо ти не задоволений.
                Жодних зайвих питань та бюрократії — просто напиши нам і гроші повернуться на твій рахунок.
              </p>
            </div>
          </div>
        </MotionSection>
      </div>
    </section>
  );
}
