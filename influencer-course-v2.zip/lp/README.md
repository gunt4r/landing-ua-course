# AniFluence — Production-Ready Landing Page

Продаючий лендинг для курсу зі створення AI-моделей. **Next.js 14 · TypeScript · Tailwind CSS · Framer Motion.**

---

## ⚡ Швидкий старт

```bash
# 1. Встановити залежності
npm install

# 2. Запустити dev-сервер
npm run dev
# → http://localhost:3000

# 3. Prod-білд
npm run build && npm start
```

---

## 📁 Структура проєкту

```
src/
├── app/
│   ├── layout.tsx          # Root layout, SEO metadata, Google Fonts
│   └── page.tsx            # Головна сторінка — збирає всі секції
│
├── components/
│   ├── layout/
│   │   ├── Header.tsx      # Sticky nav + мобільний бургер
│   │   ├── Footer.tsx      # Футер
│   │   └── StickyCTA.tsx   # Мобільний sticky CTA внизу екрана
│   │
│   ├── sections/
│   │   ├── Hero.tsx        # Hero з animated dashboard mockup
│   │   ├── SocialProof.tsx # Stats + countdown timer
│   │   ├── About.tsx       # "У чому суть?" + 3 типи доходу
│   │   ├── ForWhom.tsx     # "Для кого?" grid
│   │   ├── Results.tsx     # Відгуки + "Робота після 2 уроку"
│   │   ├── Program.tsx     # 6 модулів курсу
│   │   ├── Payment.tsx     # Pricing + бонуси + TREND
│   │   ├── AfterCourse.tsx # Phone mockup + результати
│   │   ├── Guarantee.tsx   # Гарантія 14 днів
│   │   ├── FAQ.tsx         # FAQ accordion (Framer Motion)
│   │   └── FinalCTA.tsx    # Фінальний великий CTA з glow
│   │
│   └── ui/
│       ├── CTAButton.tsx   # Анімована кнопка
│       ├── MotionSection.tsx # Scroll-reveal обгортка
│       ├── StatCounter.tsx   # Animated number counter
│       └── CountdownTimer.tsx # Live countdown
│
├── hooks/
│   ├── useReducedMotion.ts # prefers-reduced-motion detection
│   └── useCountUp.ts       # rAF-based number animation
│
├── lib/
│   └── motion.ts           # Framer Motion variants (shared)
│
└── styles/
    └── globals.css         # CSS variables, utilities, responsive
```

---

## 🎨 Дизайн-система

| Токен           | Значення     |
|----------------|-------------|
| `--accent`     | `#FF6A00`   |
| `--accent-light`| `#FF8533`  |
| `--accent-dark` | `#CC5500`  |
| `--bg`         | `#000000`   |
| `--surface`    | `#111111`   |
| `--surface-card`| `#0E0E0E`  |

**Шрифти:** Syne (display/заголовки) + DM Sans (body) — через Google Fonts.

---

## ✨ Анімації

| Компонент | Анімація |
|-----------|---------|
| Hero bars | `scaleY` з Framer Motion + stagger |
| Scroll reveals | `useInView` + `fadeUp`, `slideLeft/Right` variants |
| Stats | `useCountUp` — rAF-based, запускається при потраплянні в viewport |
| FAQ | `AnimatePresence` + `height: auto` animation |
| Final CTA | `textShadow` pulse loop |
| Phone mockup | `translateY` float loop |

**Правила оптимізації:**
- Тільки `transform` + `opacity` для GPU-акселерації
- `will-change: transform` тільки на ключових елементах
- `prefers-reduced-motion: reduce` → анімації вимкнені
- На мобільному: складні орби приховані (`hide-mobile`)
- Lottie/Canvas/Three.js — не використовуються (без важких залежностей)

---

## 📱 Mobile-first

- Sticky CTA (`StickyCTA.tsx`) — видима тільки на `≤ 768px`
- Всі кнопки `min-height: 52px`, `touch-friendly`
- Hamburger меню з `AnimatePresence` slide
- Responsive grid breakpoints: 640 / 768 / 900 / 1024px

---

## 📊 Performance checklist

- [x] `next/image` + webp/avif форматы
- [x] `removeConsole` в prod
- [x] Шрифти через `link rel="preconnect"`
- [x] Framer Motion: GPU-only props
- [x] `useInView` — lazy trigger анімацій
- [x] `prefers-reduced-motion` підтримка
- [x] Noise texture — CSS, без JS
- [x] Без важких сторонніх бібліотек

**Цільові метрики:**
- LCP < 2.5s (з оптимізованими зображеннями)
- CLS ≈ 0 (фіксовані висоти для анімованих блоків)
- FID < 100ms

---

## 🧪 Ручні перевірки

1. **Мобільна версія** → відкрий DevTools → 375px → перевір sticky CTA
2. **Reduced motion** → System Preferences → Accessibility → Reduce Motion → перевір відсутність анімацій
3. **CPU throttle** → DevTools → Performance → 4x slowdown → перевір smooth scroll
4. **LCP** → Lighthouse → Mobile → ціль < 2.5s
5. **Hamburger** → 768px → кліки по всіх пунктах меню

---

## 🔧 Кастомізація

### Кольори
`tailwind.config.ts` → `theme.extend.colors.accent`

### Тексти
Всі тексти в компонентах секцій — `src/components/sections/*.tsx`

### Ціни
`src/components/sections/Payment.tsx`

### FAQ питання
`src/components/sections/FAQ.tsx` → масив `FAQS`

---

## 📄 Ліцензія
MIT — використовуй як завгодно.
